import React from "react";
import Chatting from "../Components/Chatting/Chatting";

const ChattingPage = () => {
  return (
    <div>
      <Chatting />
    </div>
  );
};

export default ChattingPage;
