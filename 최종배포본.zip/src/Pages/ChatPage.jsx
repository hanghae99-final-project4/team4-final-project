import React from "react";
import ChatMain from "../Components/Chatting/ChatMain";
const ChatPage = () => {
  return (
    <>
      <ChatMain />
    </>
  );
};

export default ChatPage;
