import React from "react";

const RetroSlice = () => {
  return <div>RetroSlice</div>;
};

export default RetroSlice;
