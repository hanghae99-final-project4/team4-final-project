import React from "react";

const Category = () => {
  return <div></div>;
};

export default Category;
