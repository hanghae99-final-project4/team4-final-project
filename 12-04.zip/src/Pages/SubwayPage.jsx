import React from "react";
import Subway from "../Components/Chatting/Subway";
const SubwayPage = () => {
  return (
    <div>
      <Subway />;
    </div>
  );
};

export default SubwayPage;
