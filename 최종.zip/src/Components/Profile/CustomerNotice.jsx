import React from "react";

const CustomerNotice = () => {
  return <div>고객 유의 사항</div>;
};
export default CustomerNotice;
