import React from "react";

const CustomerUserGuide = () => {
  return <div>고객 이용 가이드</div>;
};
export default CustomerUserGuide;
