# 챕터 6

## 9기 실전프로젝트, 항해 99

### 소개

- FE : 4조 김재우, 이상현, 남해리
- BE : 4조 안태환, 오윤지, 성용환
- 사용 편집기 : Visual Studio Code(vscode)
- 언어 및 프레임워크와 라이브러리 : 
FE: React, Javascript, styled-component, tailwind
BE: nodejs,Javascript,JWT,PASSPORT,mySQL,swagger,socketio

