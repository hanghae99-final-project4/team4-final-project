import React from "react";

const ProfilePic = () => {
  return <div>프로필 이미지</div>;
};
export default ProfilePic;
