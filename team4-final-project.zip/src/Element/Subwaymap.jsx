import React from "react";
import { ReactComponent as Subwaymapitem } from "../Assets/Subwaymap.svg";
const Subwaymap = () => {
  return (
    <div>
      <Subwaymapitem />
    </div>
  );
};

export default Subwaymap;
