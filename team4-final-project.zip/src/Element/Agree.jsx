import React from "react";
import { ReactComponent as AgreeIcon } from "../Assets/AgreeIcon.svg";
const Agree = () => {
  return (
    <div>
      <AgreeIcon />
    </div>
  );
};
export default Agree;
